﻿// FILTER AND UPDATE FORM
// Jason Moore - Lab 3

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JasonMoore_CPT206_Lab3
{
    public partial class filterAndUpdateForm : Form
    {
        public filterAndUpdateForm()
        {
            InitializeComponent();
        }



        private void filterAndUpdateForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stateInfoDatabaseDataSet.StatesInfoTable' table. You can move, or remove it, as needed.
            this.statesInfoTableTableAdapter.Fill(this.stateInfoDatabaseDataSet.StatesInfoTable);
        }



        private void btnSaveChanges_Click_1(object sender, EventArgs e)
        {
            try
            {
                // save the data edited in the datagridview to the database
                this.statesInfoTableTableAdapter.Update(this.stateInfoDatabaseDataSet.StatesInfoTable);
                MessageBox.Show("Changes Saved Successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error - Changes Were Not Saved." + ex.Message);
            }
        }



        private void btnRefreshTable_Click(object sender, EventArgs e)
        {
            // refreshes the table after an update is made
            this.statesInfoTableTableAdapter.Fill(this.stateInfoDatabaseDataSet.StatesInfoTable);
            txtBoxSearch.Clear();
            btnSearch_Click(btnSearch, EventArgs.Empty); // trigger click event to refresh the table completely
        }



        private void btnDeleteRow_Click(object sender, EventArgs e)
        {
            try
            {
                // deletes a row from the database using the datagridview
                if (statesInfoTableDataGridView.CurrentRow != null)
                {
                    statesInfoTableDataGridView.Rows.Remove(statesInfoTableDataGridView.CurrentRow);
                }
                MessageBox.Show("Row deleted successfully.");
            }
            catch
            {
                MessageBox.Show("An Error Occured - No Rows Were Deleted.");
            }

        }



        private void btnExitApp2_Click(object sender, EventArgs e)
        {
            // exit application button for filter form
            Application.Exit();
        }



        private void btnHelp_Click(object sender, EventArgs e)
        {
            // open help form
            HelpForm helperForm = new HelpForm();
            helperForm.ShowDialog();
        }



        private void btnExitFilterUpdate_Click(object sender, EventArgs e)
        {
            // back button for filter form
            this.Close();
        }



        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string searchKeyword = txtBoxSearch.Text.Trim();

                // get like rows searching specified columns based on keyword entered into the textbox
                statesInfoTableBindingSource.Filter =
                $"StateName LIKE '%{searchKeyword}%' OR Capitol LIKE '%{searchKeyword}%' OR StateFlower LIKE '%{searchKeyword}%'";
            }
            catch
            {
                MessageBox.Show("No Special Characters Allowed.");
                return;
            }
        }
    }
}
