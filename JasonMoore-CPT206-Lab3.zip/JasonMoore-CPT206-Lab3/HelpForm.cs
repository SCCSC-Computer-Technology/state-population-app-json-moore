﻿// HELP FORM
// Jason Moore - Lab 3

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JasonMoore_CPT206_Lab3
{
    public partial class HelpForm : Form
    {
        public HelpForm()
        {
            InitializeComponent();
        }



        private void btnCloseHelp_Click(object sender, EventArgs e)
        {
            // close help form
            this.Close();
        }

    }
}
