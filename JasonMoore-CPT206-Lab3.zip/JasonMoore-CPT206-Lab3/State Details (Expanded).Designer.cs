﻿namespace JasonMoore_CPT206_Lab3
{
    partial class stateDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblStateCapitol = new System.Windows.Forms.Label();
            this.lblLgCity1 = new System.Windows.Forms.Label();
            this.lblLgCity2 = new System.Windows.Forms.Label();
            this.lblLgCity3 = new System.Windows.Forms.Label();
            this.lblStateColours = new System.Windows.Forms.Label();
            this.lblStateFlower = new System.Windows.Forms.Label();
            this.lblStateBird = new System.Windows.Forms.Label();
            this.lblPopulation = new System.Windows.Forms.Label();
            this.lblMedianIncome = new System.Windows.Forms.Label();
            this.lblComputerPcnt = new System.Windows.Forms.Label();
            this.lblStateDescription = new System.Windows.Forms.Label();
            this.lblStateName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(262, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Selected State Details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "Selected State:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "State Capitol:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(350, 244);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "Median Income:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(350, 278);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(233, 22);
            this.label5.TabIndex = 8;
            this.label5.Text = "Computer Jobs Percentage:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(22, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 22);
            this.label6.TabIndex = 9;
            this.label6.Text = "Largest City #1:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(350, 142);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 22);
            this.label7.TabIndex = 10;
            this.label7.Text = "State Bird:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(350, 77);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(124, 22);
            this.label9.TabIndex = 12;
            this.label9.Text = "State Colours:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(350, 109);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 22);
            this.label10.TabIndex = 13;
            this.label10.Text = "State Flower:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(350, 210);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 22);
            this.label11.TabIndex = 14;
            this.label11.Text = "Population:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(22, 244);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(136, 22);
            this.label12.TabIndex = 15;
            this.label12.Text = "Largest City #2:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(22, 278);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(136, 22);
            this.label13.TabIndex = 16;
            this.label13.Text = "Largest City #3:";
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.Location = new System.Drawing.Point(22, 361);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(145, 22);
            this.lbl13.TabIndex = 17;
            this.lbl13.Text = "Flag Description:";
            // 
            // btnBack
            // 
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(652, 428);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(103, 35);
            this.btnBack.TabIndex = 18;
            this.btnBack.Text = "&Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblStateCapitol
            // 
            this.lblStateCapitol.AutoSize = true;
            this.lblStateCapitol.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStateCapitol.Location = new System.Drawing.Point(164, 172);
            this.lblStateCapitol.Name = "lblStateCapitol";
            this.lblStateCapitol.Size = new System.Drawing.Size(50, 22);
            this.lblStateCapitol.TabIndex = 19;
            this.lblStateCapitol.Text = "(null)";
            // 
            // lblLgCity1
            // 
            this.lblLgCity1.AutoSize = true;
            this.lblLgCity1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLgCity1.Location = new System.Drawing.Point(164, 210);
            this.lblLgCity1.Name = "lblLgCity1";
            this.lblLgCity1.Size = new System.Drawing.Size(50, 22);
            this.lblLgCity1.TabIndex = 20;
            this.lblLgCity1.Text = "(null)";
            // 
            // lblLgCity2
            // 
            this.lblLgCity2.AutoSize = true;
            this.lblLgCity2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLgCity2.Location = new System.Drawing.Point(164, 244);
            this.lblLgCity2.Name = "lblLgCity2";
            this.lblLgCity2.Size = new System.Drawing.Size(50, 22);
            this.lblLgCity2.TabIndex = 21;
            this.lblLgCity2.Text = "(null)";
            // 
            // lblLgCity3
            // 
            this.lblLgCity3.AutoSize = true;
            this.lblLgCity3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLgCity3.Location = new System.Drawing.Point(164, 278);
            this.lblLgCity3.Name = "lblLgCity3";
            this.lblLgCity3.Size = new System.Drawing.Size(50, 22);
            this.lblLgCity3.TabIndex = 22;
            this.lblLgCity3.Text = "(null)";
            // 
            // lblStateColours
            // 
            this.lblStateColours.AutoSize = true;
            this.lblStateColours.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStateColours.Location = new System.Drawing.Point(480, 79);
            this.lblStateColours.Name = "lblStateColours";
            this.lblStateColours.Size = new System.Drawing.Size(50, 22);
            this.lblStateColours.TabIndex = 23;
            this.lblStateColours.Text = "(null)";
            // 
            // lblStateFlower
            // 
            this.lblStateFlower.AutoSize = true;
            this.lblStateFlower.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStateFlower.Location = new System.Drawing.Point(480, 109);
            this.lblStateFlower.Name = "lblStateFlower";
            this.lblStateFlower.Size = new System.Drawing.Size(50, 22);
            this.lblStateFlower.TabIndex = 24;
            this.lblStateFlower.Text = "(null)";
            // 
            // lblStateBird
            // 
            this.lblStateBird.AutoSize = true;
            this.lblStateBird.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStateBird.Location = new System.Drawing.Point(480, 142);
            this.lblStateBird.Name = "lblStateBird";
            this.lblStateBird.Size = new System.Drawing.Size(50, 22);
            this.lblStateBird.TabIndex = 25;
            this.lblStateBird.Text = "(null)";
            // 
            // lblPopulation
            // 
            this.lblPopulation.AutoSize = true;
            this.lblPopulation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPopulation.Location = new System.Drawing.Point(588, 210);
            this.lblPopulation.Name = "lblPopulation";
            this.lblPopulation.Size = new System.Drawing.Size(50, 22);
            this.lblPopulation.TabIndex = 26;
            this.lblPopulation.Text = "(null)";
            // 
            // lblMedianIncome
            // 
            this.lblMedianIncome.AutoSize = true;
            this.lblMedianIncome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedianIncome.Location = new System.Drawing.Point(588, 244);
            this.lblMedianIncome.Name = "lblMedianIncome";
            this.lblMedianIncome.Size = new System.Drawing.Size(50, 22);
            this.lblMedianIncome.TabIndex = 27;
            this.lblMedianIncome.Text = "(null)";
            // 
            // lblComputerPcnt
            // 
            this.lblComputerPcnt.AutoSize = true;
            this.lblComputerPcnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComputerPcnt.Location = new System.Drawing.Point(588, 278);
            this.lblComputerPcnt.Name = "lblComputerPcnt";
            this.lblComputerPcnt.Size = new System.Drawing.Size(50, 22);
            this.lblComputerPcnt.TabIndex = 28;
            this.lblComputerPcnt.Text = "(null)";
            // 
            // lblStateDescription
            // 
            this.lblStateDescription.AutoEllipsis = true;
            this.lblStateDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStateDescription.Location = new System.Drawing.Point(166, 361);
            this.lblStateDescription.MaximumSize = new System.Drawing.Size(300, 0);
            this.lblStateDescription.Name = "lblStateDescription";
            this.lblStateDescription.Size = new System.Drawing.Size(300, 102);
            this.lblStateDescription.TabIndex = 30;
            this.lblStateDescription.Text = "(null)";
            // 
            // lblStateName
            // 
            this.lblStateName.AutoSize = true;
            this.lblStateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStateName.Location = new System.Drawing.Point(164, 79);
            this.lblStateName.Name = "lblStateName";
            this.lblStateName.Size = new System.Drawing.Size(56, 22);
            this.lblStateName.TabIndex = 31;
            this.lblStateName.Text = "(null)";
            // 
            // stateDetailForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.CancelButton = this.btnBack;
            this.ClientSize = new System.Drawing.Size(767, 474);
            this.Controls.Add(this.lblStateName);
            this.Controls.Add(this.lblStateDescription);
            this.Controls.Add(this.lblComputerPcnt);
            this.Controls.Add(this.lblMedianIncome);
            this.Controls.Add(this.lblPopulation);
            this.Controls.Add(this.lblStateBird);
            this.Controls.Add(this.lblStateFlower);
            this.Controls.Add(this.lblStateColours);
            this.Controls.Add(this.lblLgCity3);
            this.Controls.Add(this.lblLgCity2);
            this.Controls.Add(this.lblLgCity1);
            this.Controls.Add(this.lblStateCapitol);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "stateDetailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Selected State Details";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblStateCapitol;
        private System.Windows.Forms.Label lblLgCity1;
        private System.Windows.Forms.Label lblLgCity2;
        private System.Windows.Forms.Label lblLgCity3;
        private System.Windows.Forms.Label lblStateColours;
        private System.Windows.Forms.Label lblStateFlower;
        private System.Windows.Forms.Label lblStateBird;
        private System.Windows.Forms.Label lblPopulation;
        private System.Windows.Forms.Label lblMedianIncome;
        private System.Windows.Forms.Label lblComputerPcnt;
        private System.Windows.Forms.Label lblStateDescription;
        private System.Windows.Forms.Label lblStateName;
    }
}