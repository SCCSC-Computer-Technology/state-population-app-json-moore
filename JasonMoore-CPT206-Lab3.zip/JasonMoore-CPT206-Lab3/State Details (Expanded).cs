﻿// STATE DETAILS FORM
// Jason Moore - Lab 3

using StateDataClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JasonMoore_CPT206_Lab3
{
    public partial class stateDetailForm : Form
    {

        private State _state; // accessing private field in form state class
        public stateDetailForm(State state) // constructor for state details form
        {
            InitializeComponent();

            _state = state;
            LoadStateDetails();
            
        }



        private void LoadStateDetails()
        {
            lblStateName.Text = _state.StateName;
            lblStateCapitol.Text = _state.Capitol;
            lblPopulation.Text = _state.Population.ToString();
            lblMedianIncome.Text = _state.MedianIncome.ToString("C");
            lblComputerPcnt.Text = _state.ComputerJobPercent.ToString() + "%";
            lblStateFlower.Text = _state.StateFlower;
            lblStateBird.Text = _state.StateBird;
            lblStateDescription.Text = _state.FlagDescription;
            lblStateColours.Text = _state.Colours;
            lblLgCity1.Text = _state.LargestCity1;
            lblLgCity2.Text = _state.LargestCity2;
            lblLgCity3.Text = _state.LargestCity3;
        }



        private void btnBack_Click(object sender, EventArgs e)
        {
            // close state details form
            this.Close();
        }
    }
}
