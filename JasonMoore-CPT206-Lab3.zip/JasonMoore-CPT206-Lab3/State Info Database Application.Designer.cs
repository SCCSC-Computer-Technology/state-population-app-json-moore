﻿namespace JasonMoore_CPT206_Lab3
{
    partial class stateInfoDBMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StateDropDown = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxDropDown = new System.Windows.Forms.GroupBox();
            this.btnViewStateDetails = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnFilterStates = new System.Windows.Forms.Button();
            this.groupBoxDropDown.SuspendLayout();
            this.SuspendLayout();
            // 
            // StateDropDown
            // 
            this.StateDropDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StateDropDown.FormattingEnabled = true;
            this.StateDropDown.Location = new System.Drawing.Point(23, 32);
            this.StateDropDown.Name = "StateDropDown";
            this.StateDropDown.Size = new System.Drawing.Size(432, 28);
            this.StateDropDown.TabIndex = 2;
            this.StateDropDown.Text = "Select State";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(153, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(285, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "State Info Database Application";
            // 
            // groupBoxDropDown
            // 
            this.groupBoxDropDown.Controls.Add(this.btnViewStateDetails);
            this.groupBoxDropDown.Controls.Add(this.StateDropDown);
            this.groupBoxDropDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDropDown.Location = new System.Drawing.Point(49, 98);
            this.groupBoxDropDown.Name = "groupBoxDropDown";
            this.groupBoxDropDown.Size = new System.Drawing.Size(481, 131);
            this.groupBoxDropDown.TabIndex = 4;
            this.groupBoxDropDown.TabStop = false;
            this.groupBoxDropDown.Text = "Select a state from the drop down to view its details";
            // 
            // btnViewStateDetails
            // 
            this.btnViewStateDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewStateDetails.Location = new System.Drawing.Point(283, 77);
            this.btnViewStateDetails.Name = "btnViewStateDetails";
            this.btnViewStateDetails.Size = new System.Drawing.Size(172, 35);
            this.btnViewStateDetails.TabIndex = 5;
            this.btnViewStateDetails.Text = "View State Details";
            this.btnViewStateDetails.UseVisualStyleBackColor = true;
            this.btnViewStateDetails.Click += new System.EventHandler(this.btnViewStateDetails_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(429, 307);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(142, 35);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "E&xit Application";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnFilterStates
            // 
            this.btnFilterStates.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilterStates.Location = new System.Drawing.Point(281, 307);
            this.btnFilterStates.Name = "btnFilterStates";
            this.btnFilterStates.Size = new System.Drawing.Size(142, 35);
            this.btnFilterStates.TabIndex = 6;
            this.btnFilterStates.Text = "&Filter States";
            this.btnFilterStates.UseVisualStyleBackColor = true;
            this.btnFilterStates.Click += new System.EventHandler(this.btnFilterStates_Click);
            // 
            // stateInfoDBMainForm
            // 
            this.AcceptButton = this.btnViewStateDetails;
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(583, 354);
            this.Controls.Add(this.btnFilterStates);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.groupBoxDropDown);
            this.Controls.Add(this.label1);
            this.Name = "stateInfoDBMainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "State Info Database Application";
            this.Load += new System.EventHandler(this.stateInfoDBMainForm_Load);
            this.groupBoxDropDown.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox StateDropDown;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBoxDropDown;
        private System.Windows.Forms.Button btnViewStateDetails;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnFilterStates;
    }
}

