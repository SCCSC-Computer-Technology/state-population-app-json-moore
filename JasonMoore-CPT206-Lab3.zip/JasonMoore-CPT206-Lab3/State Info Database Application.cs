﻿// MAIN STARTUP FORM
// Jason Moore - Lab 3

// created reference for state class library
using StateDataClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace JasonMoore_CPT206_Lab3
{
    public partial class stateInfoDBMainForm : Form
    {
        public stateInfoDBMainForm()
        {
            InitializeComponent();
        }



        private void stateInfoDBMainForm_Load(object sender, EventArgs e)
        {
            try
            {
                // opening connection to database
                // getting all states from the database using getallstates method
                StateRepoData stateRepository = new StateRepoData();
                var allStateNames = stateRepository.GetAllStates();

                // returning state data from database to populate combo box
                StateDropDown.DataSource = allStateNames;
                StateDropDown.DisplayMember = "StateName";
                StateDropDown.ValueMember = "StateID";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void btnExit_Click(object sender, EventArgs e)
        {
            // close main form
            this.Close();
        }



        // on button click, state details form will load to show all state info for the selected state
        private void btnViewStateDetails_Click(object sender, EventArgs e)
        {
            if (StateDropDown.SelectedValue == null)
                return;

            // state id is now stored in "id" so once the user clicks the button
            // we can get the full row using the ID from the database
            int id = (int)StateDropDown.SelectedValue;
            StateRepoData stateRepo = new StateRepoData();
            var state = stateRepo.GetStateById(id);

            try
            {
                stateDetailForm detailForm = new stateDetailForm(state);
                detailForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void btnFilterStates_Click(object sender, EventArgs e)
        {
            try
            {
                // opens form to filter states
                filterAndUpdateForm filterUpdateForm = new filterAndUpdateForm();
                filterUpdateForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
