﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StateDataClassLibrary
{
    public class State
    {
        public int StateID {  get; set; }
        public string StateName { get; set; }
        public string Capitol {  get; set; }
        public int Population { get; set; }
        public decimal MedianIncome { get; set; }
        public double ComputerJobPercent { get; set; }
        public string StateFlower { get; set; }
        public string StateBird { get; set; }
        public string FlagDescription { get; set; }
        public string Colours { get; set; }
        public string LargestCity1 { get; set; }
        public string LargestCity2 { get; set; }
        public string LargestCity3 { get; set; }
    }
}
