﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Net.Mime.MediaTypeNames;
// using a nuget package that will eliminate having to write a bunch of boilerplate code
// for sql commands. Dapper automatically maps eat row of your database to your queries.

namespace StateDataClassLibrary
{
    public class StateRepoData
    {
        // creating connection string for the local sql database
        private string connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=StateInfoDatabase;Trusted_Connection=True;";

        // making a list of states using the state class library
        // this will help get all the states from the database
        public List<State> GetAllStates()
        {
            try
            {
                using (var sqlConn = new SqlConnection(connectionString))
                {
                    sqlConn.Open(); // opening connection to DB
                    var states = sqlConn.Query<State>
                        ("Select * from StatesInfoTable").ToList();
                    return states;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to load States");
            }
        }



        // method to get the state selected from the dropdown to be able to display the details
        // in the details form
        public State GetStateById(int id)
        {
            try
            {
                using (var sqlConn = new SqlConnection(connectionString))
                {
                    sqlConn.Open(); // opening connection to DB
                    var state = sqlConn.QueryFirstOrDefault<State>
                        ("Select * from StatesInfoTable where StateID = @id", new { id = id });
                    return state;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to load States");
            }
        }
    }
}
